<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockbestsellers}prestashop>blockbestsellers-home_f7be84d6809317a6eb0ff3823a936800'] = 'No best sellers';
