<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blockcms}prestashop>blockcms_a82be0f551b8708bc08eb33cd9ded0cf'] = 'Información';
$_MODULE['<{blockcms}prestashop>blockcms_34c869c542dee932ef8cd96d2f91cae6'] = 'Nuestras tiendas';
$_MODULE['<{blockcms}prestashop>blockcms_d1aa22a3126f04664e0fe3f598994014'] = 'Promociones especiales';
$_MODULE['<{blockcms}prestashop>blockcms_9ff0635f5737513b1a6f559ac2bff745'] = 'Novedades';
$_MODULE['<{blockcms}prestashop>blockcms_02d4482d332e1aef3437cd61c9bcc624'] = 'Contacte con nosotros';
$_MODULE['<{blockcms}prestashop>blockcms_5813ce0ec7196c492c97596718f71969'] = 'Mapa del sitio';
$_MODULE['<{blockcms}prestashop>blockcms_7a52e36bf4a1caa031c75a742fb9927a'] = 'Creado por';
$_MODULE['<{blockcms}prestashop>blockcms_3cb29f0ccc5fd220a97df89dafe46290'] = 'Mejores ventas';
$_MODULE['<{blockcms}prestashop>blockcms_e1da49db34b0bdfdddaba2ad6552f848'] = 'mapa del sitio';
