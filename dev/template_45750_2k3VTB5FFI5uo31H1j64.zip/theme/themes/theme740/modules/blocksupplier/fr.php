<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocksupplier}prestashop>blocksupplier_1814d65a76028fdfbadab64a5a8076df'] = 'Fournisseurs';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_49fa2426b7903b3d4c89e2c1874d9346'] = 'En savoir plus sur';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_ecf253735ac0cba84a9d2eeff1f1b87c'] = 'Tous les fournisseurs';
$_MODULE['<{blocksupplier}prestashop>blocksupplier_496689fbd342f80d30f1f266d060415a'] = 'Aucun fournisseur';
