<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocksocial}prestashop>blocksocial_d918f99442796e88b6fe5ad32c217f76'] = 'Следуйте за нами';
$_MODULE['<{blocksocial}prestashop>blocksocial_d85544fce402c7a2a96a48078edaf203'] = 'Facebook';
$_MODULE['<{blocksocial}prestashop>blocksocial_2491bc9c7d8731e1ae33124093bc7026'] = 'Twitter';
$_MODULE['<{blocksocial}prestashop>blocksocial_bf1981220040a8ac147698c85d55334f'] = 'RSS';
