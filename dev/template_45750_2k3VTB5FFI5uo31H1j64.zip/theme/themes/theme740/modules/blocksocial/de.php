<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{blocksocial}prestashop>blocksocial_d918f99442796e88b6fe5ad32c217f76'] = 'Folgen Sie uns';
$_MODULE['<{blocksocial}prestashop>blocksocial_d85544fce402c7a2a96a48078edaf203'] = 'Facebook';
$_MODULE['<{blocksocial}prestashop>blocksocial_2491bc9c7d8731e1ae33124093bc7026'] = 'Twitter';
$_MODULE['<{blocksocial}prestashop>blocksocial_bf1981220040a8ac147698c85d55334f'] = 'RSS';
$_MODULE['<{blocksocial}prestashop>blockspecials_d1aa22a3126f04664e0fe3f598994014'] = 'Sonderangebote';
$_MODULE['<{blocksocial}prestashop>blockspecials_b4f95c1ea534936cc60c6368c225f480'] = 'Alle Specials';
$_MODULE['<{blocksocial}prestashop>blockspecials_fd21fcc9fc4c1d5202d6fc11597b3fca'] = 'Keine Sonderangebote zur Zeit';
