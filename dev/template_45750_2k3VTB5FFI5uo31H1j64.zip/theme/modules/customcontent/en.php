<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{customcontent}prestashop>customcontent_a628ecb9094c3cb78e00aa195f985b2f'] = 'CustomContent';
$_MODULE['<{customcontent}prestashop>customcontent_102410a64fbd1d545c0354366351fafb'] = 'Displays images or custom HTML in the selected hook (top, left, right)';
$_MODULE['<{customcontent}prestashop>customcontent_65e4294b4e6320d17263ce531f64faed'] = 'Unable to write to XML';
$_MODULE['<{customcontent}prestashop>customcontent_4cdd0679277501250e65f44e7ee15fa0'] = 'Can\'t close XML file';
$_MODULE['<{customcontent}prestashop>customcontent_b67c0272a2b73fab0577f3aca04268e3'] = 'Unable to update XML file. Please check file\'s permissions. Content.xml file should be open for writing.';
$_MODULE['<{customcontent}prestashop>customcontent_98495cd1fcf7185e311f7b4849f34337'] = 'Item #';
$_MODULE['<{customcontent}prestashop>customcontent_e8cf85cec621489ec026f7e06c67eb4e'] = 'Delete item';
$_MODULE['<{customcontent}prestashop>customcontent_b9b371458ab7c314f88b81c553f6ce51'] = 'Hook	';
$_MODULE['<{customcontent}prestashop>customcontent_be53a0541a6d36f6ecb879fa2c584b08'] = 'Image';
$_MODULE['<{customcontent}prestashop>customcontent_427b6d816d7fdd86cabe48d8180a3cc9'] = 'Image URL';
$_MODULE['<{customcontent}prestashop>customcontent_4c4ad5fca2e7a3f74dbb1ced00381aa4'] = 'HTML';
$_MODULE['<{customcontent}prestashop>customcontent_e4a76392c302230cbb0f2a69fbc49aa4'] = 'Image width: ';
$_MODULE['<{customcontent}prestashop>customcontent_b4a9c265a1b9e9ca4d936487db83c454'] = 'Image height: ';
$_MODULE['<{customcontent}prestashop>customcontent_30593cfa90714feb0e258eba623cbc58'] = 'Your content.xml file is empty.';
$_MODULE['<{customcontent}prestashop>customcontent_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{customcontent}prestashop>customcontent_34ec78fcc91ffb1e54cd85e4a0924332'] = 'add';
$_MODULE['<{customcontent}prestashop>customcontent_15b6acc984a377d8ae0f324666da3f5d'] = 'Add a new item';
$_MODULE['<{customcontent}prestashop>customcontent_f005bd8400ad13caa3c963e7d1220739'] = 'Item HTML is not valid';
$_MODULE['<{customcontent}prestashop>customcontent_07b8c09e490f7afbdcfa9cd5bfcfd4a9'] = 'An error occurred during the image upload.';
