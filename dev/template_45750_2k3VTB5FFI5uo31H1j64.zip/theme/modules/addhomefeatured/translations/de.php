<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{addhomefeatured}prestashop>addhomefeatured_978d481e016a17be6138e294bd92d1cc'] = 'Ausgewählte Produkte auf der Startseite';
$_MODULE['<{addhomefeatured}prestashop>addhomefeatured_bedd0eb227b31705fce270fe1ec5639f'] = 'Zeigt \\\"Ausgewählte Produkte\\\" in der Mitte Ihrer Startseite an';
$_MODULE['<{addhomefeatured}prestashop>addhomefeatured_dd0de17e8450a0fd3248b19c4a4f803b'] = 'Ungültige Anzahl von Produkten';
$_MODULE['<{addhomefeatured}prestashop>addhomefeatured_c888438d14855d7d96a2724ee9c306bd'] = 'Einstellungen aktualisiert';
$_MODULE['<{addhomefeatured}prestashop>addhomefeatured_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen';
$_MODULE['<{addhomefeatured}prestashop>addhomefeatured_6df1f9b5662398a551a2c9185b26638a'] = 'Um Artikel zu Ihrer Startseite hinzufügen, fügen Sie einfach zur \\\"Start\\\"-Kategorie hinzu.';
$_MODULE['<{addhomefeatured}prestashop>addhomefeatured_3c230497560c52be92b93c65de9defc9'] = 'Anzahl der angezeigten Produkte';
$_MODULE['<{addhomefeatured}prestashop>addhomefeatured_5bc8290012fcc597689ef8959c2fc969'] = 'Anzahl der auf der Startseite angezeigten Produkte (Standard: 10)';
$_MODULE['<{addhomefeatured}prestashop>addhomefeatured_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{addhomefeatured}prestashop>addhomefeatured_ca7d973c26c57b69e0857e7a0332d545'] = 'Ausgewählte Produkte';
$_MODULE['<{addhomefeatured}prestashop>addhomefeatured_75e182cb2bc94f597fbabb29d9fdfeec'] = 'Neu!';
$_MODULE['<{addhomefeatured}prestashop>addhomefeatured_2d0f6b8300be19cf35e89e66f0677f95'] = 'In den Korb';
$_MODULE['<{addhomefeatured}prestashop>addhomefeatured_4351cfebe4b61d8aa5efa1d020710005'] = 'Produkt ansehen';
$_MODULE['<{addhomefeatured}prestashop>addhomefeatured_e0e572ae0d8489f8bf969e93d469e89c'] = 'Keine ähnlichen Artikel';
