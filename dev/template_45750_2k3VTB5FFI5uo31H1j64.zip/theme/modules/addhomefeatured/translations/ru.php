<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{addhomefeatured}prestashop>addhomefeatured_978d481e016a17be6138e294bd92d1cc'] = 'Популярные товары на главной';
$_MODULE['<{addhomefeatured}prestashop>addhomefeatured_bedd0eb227b31705fce270fe1ec5639f'] = 'Отображает Рекомендуемые товары в средней части главной страницы.';
$_MODULE['<{addhomefeatured}prestashop>addhomefeatured_dd0de17e8450a0fd3248b19c4a4f803b'] = 'Неверное количество товаров';
$_MODULE['<{addhomefeatured}prestashop>addhomefeatured_c888438d14855d7d96a2724ee9c306bd'] = 'Настройки обновлены';
$_MODULE['<{addhomefeatured}prestashop>addhomefeatured_f4f70727dc34561dfde1a3c529b6205c'] = 'Настройки';
$_MODULE['<{addhomefeatured}prestashop>addhomefeatured_6df1f9b5662398a551a2c9185b26638a'] = 'Для того, чтобы добавить популярные товары на главную страницу, просто добавьте их в домашнюю категорию.';
$_MODULE['<{addhomefeatured}prestashop>addhomefeatured_3c230497560c52be92b93c65de9defc9'] = 'Количество отображаемых товаров';
$_MODULE['<{addhomefeatured}prestashop>addhomefeatured_5bc8290012fcc597689ef8959c2fc969'] = 'Количество товаров, отображаемых на главной странице (по умолчанию: 10).';
$_MODULE['<{addhomefeatured}prestashop>addhomefeatured_c9cc8cce247e49bae79f15173ce97354'] = 'Сохранить';
$_MODULE['<{addhomefeatured}prestashop>addhomefeatured_ca7d973c26c57b69e0857e7a0332d545'] = 'Рекомендуемые товары';
$_MODULE['<{addhomefeatured}prestashop>addhomefeatured_75e182cb2bc94f597fbabb29d9fdfeec'] = 'Новинка';
$_MODULE['<{addhomefeatured}prestashop>addhomefeatured_2d0f6b8300be19cf35e89e66f0677f95'] = 'В корзину';
$_MODULE['<{addhomefeatured}prestashop>addhomefeatured_4351cfebe4b61d8aa5efa1d020710005'] = 'Подробнее';
$_MODULE['<{addhomefeatured}prestashop>addhomefeatured_e0e572ae0d8489f8bf969e93d469e89c'] = 'Нет рекомендуемых товаров';
